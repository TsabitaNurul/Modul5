package com.example.gmaps;

import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.getUiSettings().setZoomControlsEnabled(true);

        // Add a marker in Sydney and move the camera
        LatLng sman16 = new LatLng(-0.470344,117.139368);
        mMap.addMarker(new MarkerOptions().position(sman16).title("SMAN 16 Samarinda"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sman16));

        LatLng sman5 = new LatLng(-0.484779,117.128421);
        mMap.addMarker(new MarkerOptions().position(sman5).title("SMAN 5 Samarinda"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sman5));

        LatLng sman3 = new LatLng(-0.485514,117.128842);
        mMap.addMarker(new MarkerOptions().position(sman3).title("SMAN 3 Samarinda"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sman3));

        LatLng sman1= new LatLng(-0.465101,117.130121);
        mMap.addMarker(new MarkerOptions().position(sman1).title("SMAN 1 Samarinda"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sman1));

        mMap.addPolyline(new PolylineOptions().add(
                sman16,
                new LatLng(-0.470409, 117.139358),
                new LatLng(-0.470414, 117.139119),
                new LatLng(-0.470694, 117.139154),
                new LatLng(-0.473280, 117.138221),
                new LatLng(-0.474128, 117.138232),
                new LatLng(-0.479935, 117.135869),
                new LatLng(-0.480496, 117.135480),
                new LatLng(-0.481484, 117.134279),
                new LatLng(-0.482286, 117.132359),
                new LatLng(-0.482983, 117.130746),
                new LatLng(-0.484267, 117.128040),
                new LatLng(-0.484696, 117.128233),
                sman5
        ).color(Color.BLUE));
    }
}
